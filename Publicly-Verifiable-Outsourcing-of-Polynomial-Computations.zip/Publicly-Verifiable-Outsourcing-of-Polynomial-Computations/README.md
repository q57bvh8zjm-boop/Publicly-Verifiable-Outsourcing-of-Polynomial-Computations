# Publicly Verifiable Outsourcing of Polynomial Computations

This repository contains the C artifact accompanying the paper *Publicly Verifiable Outsourcing of Polynomial Computations*. It implements the three proposed constructions, Gamma1, Gamma2, and Gamma3, and includes the Pi3 private-verification baseline used in the paper.

The repository also records the exact relationship between implementation files, experiment parameters, and paper figures. Reported numerical coordinates are kept separately from freshly generated benchmark data so that the artifact does not overstate its current reproducibility.

## Quick start

On Ubuntu 22.04 or a compatible Debian-based system:

```bash
sudo apt-get update
sudo apt-get install build-essential libflint-dev libgmp-dev libsodium-dev python3
make check
```

`make check` validates the reported-data grids, checks source hygiene, builds all shipped programs, and runs the polynomial-evaluation tests.

To redraw the coordinates reported in the paper:

```bash
python3 -m pip install matplotlib
make reported-plots
```

The plots are written to `results/plots/`.

## Repository layout

```text
.
|-- protocols/
|   |-- scheme1.c, scheme1.h          Gamma1
|   |-- scheme2.c, scheme2.h          Gamma2
|   |-- scheme3.c, scheme3.h          Gamma3
|   |-- protocol2.c, protocol2.h      Pi3 comparison baseline
|   |-- scheme3_pir_optimize.c        exploratory PIR estimator
|   `-- protocol2_pir_optimize.c      exploratory baseline estimator
|-- lib/common/
|   |-- mpoly.c, mpoly.h              dense polynomial evaluation
|   `-- extended_field.c, .h          explicit F_(q^2) arithmetic
|-- tests/test_mpoly.c                 degree-3 evaluator regression tests
|-- results/reported/                  coordinates transcribed from the paper
|-- scripts/
|   |-- plot_reported_results.py       reported-coordinate plotting
|   `-- validate_artifact.py           grid and source validation
|-- benchmarks/README.md               raw-driver requirements and CSV schema
|-- SOURCE_CODE_MAP.md                 detailed paper-to-code mapping
|-- REPRODUCIBILITY_STATUS.md          supported and unsupported claims
|-- ARTIFACTS.md
`-- Makefile
```

There is no Scheme 4 in the paper. References to nonexistent `scheme4.c` and `scheme4.h` in the original artifact metadata and build rules have been removed.

## Construction-to-source mapping

| Paper construction | Implementation | Main implementation path |
|---|---|---|
| Gamma1 | Publicly verifiable MSVC over an explicit extension field | `protocols/scheme1.c`, `lib/common/extended_field.c` |
| Gamma2 | Shamir-shared curves with orthogonal-vector verification | `protocols/scheme2.c`, `lib/common/mpoly.c` |
| Gamma3 | Two-server Paillier/HSS construction | `protocols/scheme3.c` |
| Pi3 baseline | Private-verification extension-field construction | `protocols/protocol2.c` |

## Paper experiments and included data

The paper defines the client improvement ratio

```text
Rt* = (Tp + Tv + Td) / Tn
```

where `Tn` is native polynomial-evaluation time, and `Tp`, `Tv`, and `Td` are the client-side ProbGen, Verify, and Decode/Reconstruct times. KeyGen is excluded because it can be amortized. Figures 2--4 plot `log2(Rt*)`.

| Paper result | Schemes and parameter grid | Included reported data | Current raw driver status |
|---|---|---|---|
| Figure 2 (`fig:Output1`) | Gamma1--3; `d=2`, `t=1`, `m=200,400,...,2000` | `results/reported/figure2_low_degree.csv` | Original end-to-end timing driver is not present |
| Figure 3 (`fig:Rt`) | Gamma1--2; `d=2`, `t=2,3`, `m=200,400,...,2000` | `results/reported/figure3_thresholds.csv` | Original end-to-end timing driver is not present |
| Figure 4 (`fig:bigd`) | Gamma1--3; `d=4,8,10`, `t=1`, `m=1,...,15` | `results/reported/figure4_high_degree.csv` | Native, Gamma1, and Gamma2 dense evaluation are implemented; Gamma3 HSS evaluation remains linear-only |
| Table `tab:micro` | 100 trials per primitive | `results/reported/table_microbenchmark.csv` | Original exact microbenchmark driver is not present |
| Figure 5 (`fig:tc_gamma1_pi3`) | Gamma1/Pi3; `d=2,3`, `t=1,2`, `m=200,400,...,2000` | `results/reported/figure5_gamma1_vs_pi3.csv` | Pi3 now supports `d=3`; original end-to-end timing driver is not present |

The files under `results/reported/` are transcriptions of numerical coordinates printed in the paper. They regenerate the reported plots, but they are not fresh timing logs. See `REPRODUCIBILITY_STATUS.md` before making reproducibility claims.

## Dense polynomial representation

`lib/common/mpoly.c` defines one coefficient order for a dense polynomial in `m` variables with total degree at most `d`:

```text
degree 0: 1
degree 1: x0, x1, ..., x(m-1)
degree 2: x0^2, x0*x1, ..., x(m-1)^2
degree 3: x0^3, x0^2*x1, ..., x(m-1)^3
...
```

Within each degree, a monomial is represented by a nondecreasing tuple of variable indices. The number of coefficients is `C(m + d, d)`.

The same graded order is used by the native evaluator, Gamma1 extension-field evaluator, Gamma2 through the shared evaluator, and the Pi3 baseline. The regression test covers a complete two-variable degree-3 polynomial in all three evaluator variants.

Run the tests directly with:

```bash
make test
```

## Build targets

| Command | Purpose |
|---|---|
| `make all` | Build core objects and the two exploratory PIR programs |
| `make core` | Build only the construction and common-library objects |
| `make test` | Build and run polynomial evaluator regression tests |
| `make validate` | Validate all Figure 2--5 grids and source hygiene |
| `make check` | Run validation, tests, and the complete build |
| `make var_benchmark` | Build the exploratory VAR estimator |
| `make reported-plots` | Replot the paper's reported coordinates |
| `make clean` | Remove generated native binaries and objects |

The Makefile detects common Homebrew FLINT locations on macOS. The artifact is also checked on Ubuntu through `.github/workflows/ci.yml`.

## Reported experimental platform

- Client VM: Ubuntu Desktop 20.04.2 LTS, 4 GB RAM, one Intel i7-6700 core limited to 800 MHz.
- Server VM: Ubuntu Desktop 20.04.2 LTS, 32 GB RAM, one 2.30 GHz Intel Xeon Gold 5218 core.
- The VMs used bridged networking on the same physical workstation and communicated over TCP.
- Default security parameter: 128 bits.
- Reported software versions: FLINT 2.8.0 and libsodium 1.0.18.
- Reported group: ristretto255 through libsodium.

Current systems may use newer compatible library versions. Record the actual versions and machine configuration with any newly generated timing results.

## Reproducibility boundary

This revision fixes the arbitrary-degree dense evaluators used by native evaluation, Gamma1, Gamma2, and Pi3, removes timing-distorting debug output from Gamma3 verification, and adds executable tests and CI. It does not reconstruct the missing original timing harness or silently substitute analytical values for measured timings.

Gamma3's shipped HSS evaluator currently computes a linear combination of encrypted inputs. Extending it to arbitrary polynomial degree requires a protocol-level HSS circuit implementation and validation against the reference construction. Therefore a fresh end-to-end reproduction of every Gamma3 point in Figure 4 is not yet supported by this source tree.

For the full claim-by-claim status, read `REPRODUCIBILITY_STATUS.md` and `SOURCE_CODE_MAP.md`.
